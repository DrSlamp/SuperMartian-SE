from src.loaders.TmxLevelLoader import TmxLevelLoader

(TmxLevelLoader,)
